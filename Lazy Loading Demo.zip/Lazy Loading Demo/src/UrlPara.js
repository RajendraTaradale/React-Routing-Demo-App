
import React, { Component } from 'react';

class UrlPara extends Component {
       render() {
        return (
            <div>
                User Navigated to : {this.props.match.params.id}
                <p>
                    match contains : ${JSON.stringify(this.props.match,null,4)}
                </p>
            </div> 
        );
    }
}

export default UrlPara;
// const UrlPara = ({ match }) => {
//       <div>
//        <h1>URL Details</h1>
//         <div> You have navigated to ${match.url}</div>
//       </div>
//   }

// export default UrlPara;