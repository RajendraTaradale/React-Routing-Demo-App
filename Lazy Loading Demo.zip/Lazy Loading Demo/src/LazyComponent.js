import React, { Component } from 'react';

class LazyComponent extends Component {
    render() {
        return (
            <div>
                Loaded on demand - When user navigated to LazyComponent
            </div>
        );
    }
}

export default LazyComponent;