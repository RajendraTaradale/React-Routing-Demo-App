import React, { Component } from "react";
import "./App.css";
import { BrowserRouter as Router, NavLink, Route , Switch } from "react-router-dom";
import Contact from "./Contact";
import Blog from "./blogs";
import App2 from './RouterPara';

class App extends Component {
   render() {
    return (
      <Router>
        <div className="App">
          <nav className="navbar navbar-expand-lg navbar-light bg-light navbar-static-top">
            {/* <a className="navbar-brand" href="https://rajendrataradale.wordpress.com/author/rajendrataradale/">
              RT's Knowledge World
            </a> */}
            <NavLink
                    to="/"
                    className="navbar-brand"
                    exact
                    activeStyle={{ color: "black" }}
                  >
                   RT's Knowledge World
                  </NavLink>
            <button
              className="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon" />
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item active">
                  <NavLink
                    to="/"
                    className="nav-link"
                    exact
                    activeStyle={{ color: "black" }}
                  >
                    Home
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    to="/about"
                    className="nav-link"
                    exact
                    activeStyle={{ color: "black" }}
                  >
                    About
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    to="/blog"
                    className="nav-link"
                    exact
                    activeStyle={{ color: "black" }}
                  >
                    Blogs
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    to="/contact"
                    className="nav-link"
                    exact
                    activeStyle={{ color: "black" }}
                  >
                    Site Admin
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    to="/data"
                    className="nav-link"
                    exact
                    activeStyle={{ color: "black" }}
                  >
                    Test Data
                  </NavLink>
                </li>
              </ul>
            </div>
          </nav>
          <hr className="my-4" />
          <div>
            <Switch>
            <Route
              path="/"
              exact
              strict
              render={() => {
                return (
                  <div className="jumbotron container row">
                    <h1 className="display-4">Welcome Home!</h1>
                    <p className="lead">
                      Unless you try to do something beyond what you have
                      already mastered, you will never grow
                    </p>
                    <hr className="my-4" />
                    <p>
                      Sometimes it’s necessary to go a long distance out of the
                      way in order to come back a short distance correctly.
                    </p>
                    <br />
                    <a
                      className="btn btn-primary btn-lg"
                      href="https://rajendrataradale.wordpress.com/author/rajendrataradale/"
                      role="button"
                    >
                      Learn more
                    </a>
                  </div>
                );
              }}
            />

            <Route
              path="/about"
              exact
              strict
              render={() => {
                return (
                  <div className="card">
                    <div className="card-header">Rajendra Taradale</div>
                    <div className="card-body">
                      <blockquote className="blockquote mb-0">
                        <p>
                          Over 8 Years of experience in IT Industry. Hands-on
                          experience in all phases of Software Development Life
                          Cycle (SDLC) in Web and Windows Applications under
                          Agile Framework (Scrum, Kanban, and SAFe-Scaled)
                        </p>
                        <footer className="blockquote-footer">
                          Welcome
                          <cite title="Source Title">
                              RT's Knowledge World
                          </cite>
                        </footer>
                      </blockquote>
                    </div>
                  </div>
                );
              }}
            />
            <Route path="/blog" exact strict component={Blog} />
            <Route path="/contact" exact strict component={Contact} />
            <Route path="/data" exact strict component={App2} />
            </Switch>
          </div>
        </div>
      </Router>
    );
  }
}

export default App;
