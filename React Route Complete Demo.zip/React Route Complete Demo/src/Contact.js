import React, { Component } from 'react';

class Contact extends Component {
    constructor(props) {
      super(props);
      this.handleUserInput=this.handleUserInput.bind(this);
      this.onSave=this.onSave.bind(this);
        this.state = {
            email: '',
            password: '',
            formErrors: {email: '', password: ''},
            emailValid: false,
            passwordValid: false,
            formValid: false
          }
    }
    handleUserInput (e) {
        const name = e.target.name;
        const value = e.target.value;
        this.setState({[name]: value}, 
                      () => { this.validateField(name, value) });
      }

      validateField(fieldName, value) {
        let fieldValidationErrors = this.state.formErrors;
        let emailValid = this.state.emailValid;
        let passwordValid = this.state.passwordValid;
      
        switch(fieldName) {
          case 'email':
            emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
            fieldValidationErrors.email = emailValid ? '' : ' is invalid';
            break;
          case 'password':
            passwordValid = value.length >= 6;
            fieldValidationErrors.password = passwordValid ? '': ' is too short';
            break;
          default:
            break;
        }
        this.setState({formErrors: fieldValidationErrors,
                        emailValid: emailValid,
                        passwordValid: passwordValid
                      }, this.validateForm);
      }
      
      validateForm() {
        this.setState({formValid: this.state.emailValid && this.state.passwordValid});
      }
      onSave(){
          console.log(this.state);
      }
      errorClass(error) {
        return(error.length === 0 ? '' : 'has-error');
      }

      

    render() {
        return (<div className="row">
            <div className="col-sm-3"></div>
            <div className="col-sm-6">
                              <form className="demoForm">
                <h2>Log In</h2>
                {/* <div className="panel panel-default">
                    <FormCustomErrorsHandler formErrors={this.state.formErrors} />
                </div> */}
                <div className={`form-group ${this.errorClass(this.state.formErrors.email)}`}>
                <div className="input-group mb-3">
            <div className="input-group-prepend">
                <span className="input-group-text" id="basic-addon1">@</span>
            </div>
            <input type="email" className="form-control" placeholder="Email / User Id" name="email" value={this.state.email} onChange={this.handleUserInput} aria-label="Username" aria-describedby="basic-addon1"/>
            </div>
                </div>
                <div className={`form-group ${this.errorClass(this.state.formErrors.password)}`}>
                <div className="input-group mb-3">
            <div className="input-group-prepend">
                <span className="input-group-text" id="basic-addon1">$</span>
            </div>
            <input type="password" className="form-control" placeholder="Password" name="password" value={this.state.password} onChange={this.handleUserInput} aria-label="Username" aria-describedby="basic-addon1"/>
            </div>
             </div>
                <button type="button" onClick={() => this.onSave()} className="btn btn-primary" disabled={!this.state.formValid}>Sign up</button>
                </form>
                           </div>
                              <div className="col-sm-3"></div></div>

        );
    }
}

export default Contact;

export const FormCustomErrorsHandler = ({formErrors}) =>
  <div className='formErrors'>
    {Object.keys(formErrors).map((fieldName, i) => {
      if(formErrors[fieldName].length > 0){
        return (
          <p key={i}>{fieldName.toUpperCase()} - {formErrors[fieldName]}</p>
        )        
      } else {
        return '';
      }
    })}
  </div>