import React, {  } from 'react';
class EmployeeRow extends React.Component 
  
{
    render () {  
        return(  
            <tr>  
                <td>{this.props.item.id}</td>  
                <td>{this.props.item.title}</td>  
                <td>{this.props.item.url}</td>  
                <td>{this.props.item.thumbnailUrl}
                <img src={this.props.item.thumbnailUrl} width="100" height="50" />
                </td>  
            </tr>  
            );  
    }  
} 

// var EmployeeTable = React.createClass({  
class EmployeeTable extends React.Component       
{
   
        constructor(props){
            super(props)
            this.state = {
                result:[], 
                IsLoader:true
            }
         
        }
        
    componentWillMount(){  
        var xhr = new XMLHttpRequest();  
        xhr.open('get', this.props.url, true);  
        xhr.onload = function () {  
            var response = JSON.parse(xhr.responseText);  
            this.setState({ result: response,
                IsLoader:false});  

        }.bind(this);  
        xhr.send();  
    }
    render(){  
        var rows = [];  
        this.state.result.forEach(function (item) {  
            rows.push(<EmployeeRow  key={item.id} item={item}/>);  
    });  

    if(this.state.IsLoader){
        return ( 
            <div>Loading Data Please Wait!</div>)
    }else{
                    return ( 
                <div>
                <table className="table">  
                <thead>  
                    <tr>  
                        <th>AlbumId</th>  
                        <th>Title</th>  
                        <th>Url</th>  
                        <th>ThumbnailUrl</th>   
                    </tr>  
                </thead>  

                    <tbody>  
                        {rows}  
                    </tbody>  

                </table></div>);  
                }  
    }
    
}

export default EmployeeTable;