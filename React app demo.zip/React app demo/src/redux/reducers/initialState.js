export default {
  courses: [],
  authors: [],
  apiCallsInProgress: 0
};
