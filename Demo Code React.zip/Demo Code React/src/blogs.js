import React, { Component } from 'react';

class Blog extends Component {
    constructor(props){
        super(props)

    }
    render() {
        var BlogsSites = ['C# Corner', 'Linked In', 'WordPress'];

        var blogCollection=[{
            name:'C# Corner',
            url:'https://www.c-sharpcorner.com/members/rajendra-taradale3'},
            {
                name:'WordPress',
                url:'https://rajendrataradale.wordpress.com/author/rajendrataradale/'},
                {
                    name:'Linked In',
                    url:'https://www.linkedin.com/in/rajendra-taradale/'}
        ];

        return (
            <div>
             
            {blogCollection.map(function(d, index){
               return <div className="card text-white bg-dark mb-3" >
                <div className="card-header">{d.name}</div>
                <div className="card-body">
                   <a className="card-text" href={d.url} role="button">{d.url}</a>
                </div>
                </div>
                  })}
            </div>
        );
    }
}

export default Blog;