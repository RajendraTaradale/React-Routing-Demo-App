import React from "react";
const AuthContext = new React.createContext();
export default AuthContext;
